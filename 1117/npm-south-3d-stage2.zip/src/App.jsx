import React, { useEffect, useMemo, useState } from 'react';
import { Canvas } from '@react-three/fiber';
import { Sky, Sparkles, Text, OrbitControls } from '@react-three/drei';
import { IslandWorld } from './World.jsx';
import { hasSupabase, supabase } from './supabase.js';
import { ShoppingBag, UserRound, Compass, X, MessageCircle, LogOut, Menu, Plus, Minus, ArrowUp, ArrowDown, ArrowLeft, ArrowRight } from 'lucide-react';

const islands = [
  { id:'ink', name:'水墨之島', subtitle:'東方藝術與水墨', color:'#9ab9b3', story:'風從湖面吹來，墨色在水中慢慢暈開。島上的守卷人收藏著一幅沒有落款的山水畫。找到散落的三枚印記，就能聽見畫中人的故事。', npc:'守卷人・墨禾', greeting:'旅人，你看見遠方那座山了嗎？它不在紙上，而是在每個願意停下腳步的人心裡。' },
  { id:'ceramic', name:'瓷器之島', subtitle:'陶瓷與工藝', color:'#6f9da7', story:'窯火熄滅後，島上留下許多等待被理解的紋樣。青花、釉色與器形，記錄著遠方的旅程。', npc:'陶藝師・青嶼', greeting:'每一道釉色都有自己的時間。你想先認識青花，還是聽聽器物旅行的故事？' },
  { id:'textile', name:'織夢之島', subtitle:'亞洲織品與服飾', color:'#c69b76', story:'風穿過織機，將不同地方的色彩交織在一起。這裡的圖案不是裝飾，而是一封封寫給未來的信。', npc:'織夢者・蘭紗', greeting:'看見布上的花紋了嗎？有些記錄季節，有些記錄祝福。' },
  { id:'civil', name:'文明之島', subtitle:'亞洲文化交流', color:'#b59cbd', story:'三條古道在島中央交會。商旅、工匠與思想曾在此相遇，讓不同文明彼此照亮。', npc:'旅史學者・迦南', greeting:'文明從來不是孤島。你願意沿著古道，找找那些交流留下的痕跡嗎？' },
  { id:'shop', name:'拾藏之島', subtitle:'文創與收藏', color:'#d4b879', story:'每一件小小的收藏，都能把一段旅程帶回日常。挑選你喜歡的紀念品，替這趟旅程留下記號。', npc:'選物店主・拾一', greeting:'歡迎來到拾藏商店！看看有沒有一件小物，能替你的旅程留下記憶。' }
];

const products = [
  {id:1,name:'青花紋樣明信片組',price:180,desc:'以瓷器紋樣為靈感的藝術明信片。',emoji:'🪷'},
  {id:2,name:'山水流雲帆布袋',price:420,desc:'將水墨山水的留白帶進日常。',emoji:'🎐'},
  {id:3,name:'織夢紋樣筆記本',price:260,desc:'收藏亞洲織品的色彩與圖樣。',emoji:'📔'},
  {id:4,name:'拾境紀念徽章',price:120,desc:'五座文化島嶼限定紀念徽章。',emoji:'🏵️'}
];

function AccountModal({onClose,user,onLogin,onLogout}) {
  const [email,setEmail]=useState(''); const [password,setPassword]=useState(''); const [mode,setMode]=useState('login'); const [message,setMessage]=useState('');
  async function submit(e){e.preventDefault();setMessage('');try{await onLogin(email,password,mode);setMessage(mode==='login'?'登入成功！':'註冊成功，請留意信箱驗證。');}catch(err){setMessage(err.message||'操作失敗，請再試一次。');}}
  return <div className="veil" onClick={onClose}><section className="modal account" onClick={e=>e.stopPropagation()}><button className="close" onClick={onClose}><X/></button>
    <div className="eyebrow">YOUR JOURNEY BEGINS</div><h2>旅人帳戶</h2>
    {user?<><p className="muted">目前登入：{user.email||user.name}</p><button className="primary wide" onClick={onLogout}>登出帳戶 <LogOut size={16}/></button></>:<form onSubmit={submit}>
      <label>電子郵件<input type="email" required value={email} onChange={e=>setEmail(e.target.value)} placeholder="name@example.com"/></label>
      <label>密碼<input type="password" required minLength="6" value={password} onChange={e=>setPassword(e.target.value)} placeholder="至少 6 個字元"/></label>
      <button className="primary wide" type="submit">{mode==='login'?'登入探索世界':'建立會員'}</button>
      <button type="button" className="text-button" onClick={()=>setMode(mode==='login'?'signup':'login')}>{mode==='login'?'還沒有帳戶？立即註冊':'已有帳戶？返回登入'}</button>
      {message&&<p className="notice">{message}</p>}
      {!hasSupabase&&<p className="tiny-note">目前為展示模式：帳號只保存在此瀏覽器，正式會員功能請設定 Supabase。</p>}
    </form>}</section></div>
}
function ShopModal({cart,setCart,onClose}) {
 const [done,setDone]=useState(false); const count=Object.values(cart).reduce((a,b)=>a+b,0); const total=products.reduce((a,p)=>a+p.price*(cart[p.id]||0),0);
 return <div className="veil" onClick={onClose}><section className="modal shop" onClick={e=>e.stopPropagation()}><button className="close" onClick={onClose}><X/></button><div className="eyebrow">SOUVENIR COLLECTION</div><h2>拾藏文創商店</h2><p className="muted">把島嶼故事，收藏進日常。</p>
 <div className="products">{products.map(p=><article className="product" key={p.id}><div className="product-art">{p.emoji}</div><div className="product-info"><b>{p.name}</b><small>{p.desc}</small><strong>NT$ {p.price}</strong></div><div className="qty"><button onClick={()=>setCart(c=>({...c,[p.id]:Math.max(0,(c[p.id]||0)-1)}))}><Minus size={14}/></button><span>{cart[p.id]||0}</span><button onClick={()=>setCart(c=>({...c,[p.id]:(c[p.id]||0)+1}))}><Plus size={14}/></button></div></article>)}</div>
 <div className="cart-total"><span>購物車 {count} 件</span><b>NT$ {total.toLocaleString('zh-TW')}</b></div>
 {done?<p className="notice">已建立展示訂單！目前尚未串接真實付款。</p>:<button className="primary wide" disabled={!count} onClick={()=>setDone(true)}>確認購物清單</button>}
 <p className="tiny-note">此為功能原型，尚未連接金流，不會實際收款。</p></section></div>
}
function StoryModal({island,onClose}) {
 return <div className="veil" onClick={onClose}><section className="modal story" onClick={e=>e.stopPropagation()}><button className="close" onClick={onClose}><X/></button><div className="eyebrow">ISLAND CHRONICLE</div><h2>{island.name}</h2><p className="story-sub">{island.subtitle}</p><div className="story-art" style={{background:`linear-gradient(135deg, ${island.color}, #183b42)`}}>✧</div><p className="story-copy">{island.story}</p><div className="npc-card"><div className="npc-avatar">✦</div><div><small>島嶼引路人</small><b>{island.npc}</b><p>「{island.greeting}」</p></div></div><button className="primary wide" onClick={onClose}>繼續探索</button></section></div>
}
function App() {
 const [user,setUser]=useState(null); const [account,setAccount]=useState(false); const [shop,setShop]=useState(false); const [active,setActive]=useState(null); const [chat,setChat]=useState(null); const [story,setStory]=useState(null); const [cart,setCart]=useState(()=>JSON.parse(localStorage.getItem('npm-cart')||'{}')); const [keys,setKeys]=useState({}); const [mobileMenu,setMobileMenu]=useState(false); const [toast,setToast]=useState(''); const [avatarName,setAvatarName]=useState('拾境旅人'); const [remotePlayers,setRemotePlayers]=useState([]); const [onlineCount,setOnlineCount]=useState(1); const channelRef=React.useRef(null); const playerId=React.useRef(crypto.randomUUID?.()||String(Math.random()).slice(2));
 useEffect(()=>{localStorage.setItem('npm-cart',JSON.stringify(cart));},[cart]);
 useEffect(()=>{if(!hasSupabase){const saved=localStorage.getItem('npm-demo-user');if(saved)setUser(JSON.parse(saved));return;}supabase.auth.getSession().then(({data})=>setUser(data.session?.user||null));const {data:{subscription}}=supabase.auth.onAuthStateChange((_e,session)=>setUser(session?.user||null));return()=>subscription.unsubscribe();},[]);
 useEffect(()=>{
   if(!hasSupabase) return;
   const channel=supabase.channel('npm-south-world',{config:{presence:{key:playerId.current},broadcast:{self:false}}});
   channelRef.current=channel;
   channel.on('presence',{event:'sync'},()=>{
     const state=channel.presenceState(); const people=[];
     Object.entries(state).forEach(([key,items])=>{if(key!==playerId.current&&items?.[0]?.position)people.push({...items[0],id:key});});
     setRemotePlayers(people); setOnlineCount(Object.keys(state).length||1);
   });
   channel.on('broadcast',{event:'player-move'},({payload})=>{
     setRemotePlayers(prev=>{const found=prev.some(p=>p.id===payload.id);return found?prev.map(p=>p.id===payload.id?{...p,...payload}:p):[...prev,payload];});
   });
   channel.subscribe(async status=>{
     if(status==='SUBSCRIBED'){
       await channel.track({name:user?.email?.split('@')[0]||'旅人',position:{x:0,z:0},updatedAt:Date.now()});
     }
   });
   return ()=>{channelRef.current=null;supabase.removeChannel(channel);};
 },[user]);
 const sendPosition=React.useCallback((position)=>{
   if(!channelRef.current)return;
   const payload={id:playerId.current,name:user?.email?.split('@')[0]||'旅人',position,updatedAt:Date.now()};
   channelRef.current.track(payload).catch(()=>{});
   channelRef.current.send({type:'broadcast',event:'player-move',payload}).catch(()=>{});
 },[user]);
 useEffect(()=>{const down=e=>{if(['ArrowUp','ArrowDown','ArrowLeft','ArrowRight','w','a','s','d','W','A','S','D'].includes(e.key)){e.preventDefault();setKeys(k=>({...k,[e.key.toLowerCase()]:true}));}if(e.key.toLowerCase()==='e')setChat(active);};const up=e=>setKeys(k=>({...k,[e.key.toLowerCase()]:false}));window.addEventListener('keydown',down);window.addEventListener('keyup',up);return()=>{window.removeEventListener('keydown',down);window.removeEventListener('keyup',up);};},[active]);
 async function login(email,password,mode){if(hasSupabase){const result=mode==='login'?await supabase.auth.signInWithPassword({email,password}):await supabase.auth.signUp({email,password});if(result.error)throw result.error;setUser(result.data.user);return;}const demo={email,name:email.split('@')[0]};localStorage.setItem('npm-demo-user',JSON.stringify(demo));setUser(demo);}
 async function logout(){if(hasSupabase)await supabase.auth.signOut();else localStorage.removeItem('npm-demo-user');setUser(null);}
 function openIsland(id){const item=islands.find(i=>i.id===id);setActive(item);if(id==='shop')setShop(true);else setChat(item);}
 function say(text){setToast(text);setTimeout(()=>setToast(''),2600);}
 const cartCount=Object.values(cart).reduce((a,b)=>a+b,0);
 return <main className="app-shell">
  <header className="topbar"><a className="brand" href="#"><span className="brand-mark">拾</span><span><b>故宮南院・拾境</b><small>SOUTHERN BRANCH · CULTURAL ISLANDS</small></span></a>
   <nav className={mobileMenu?'nav open':'nav'}><button onClick={()=>{setActive(null);setChat(null);setMobileMenu(false)}}>探索園區</button><button onClick={()=>{setShop(true);setMobileMenu(false)}}>文創商店</button><button onClick={()=>{setAccount(true);setMobileMenu(false)}}>會員中心</button></nav>
   <div className="top-actions"><button className="icon-button cart-button" onClick={()=>setShop(true)} aria-label="購物車"><ShoppingBag size={18}/>{cartCount>0&&<i>{cartCount}</i>}</button><button className="account-button" onClick={()=>setAccount(true)}><UserRound size={16}/><span>{user?.email?.split('@')[0]||user?.name||'旅人登入'}</span></button><button className="icon-button mobile-menu" onClick={()=>setMobileMenu(v=>!v)}><Menu/></button></div>
  </header>
  <section className="hero"><div className="hero-copy"><div className="eyebrow">A DIGITAL CULTURAL JOURNEY</div><h1>在湖光之間，<br/><em>拾起文化的故事。</em></h1><p>穿越五座主題島嶼，遇見藝術、器物與文明。<br/>創造你的旅人角色，展開一場自由探索。</p><div className="hero-actions"><button className="primary" onClick={()=>say('使用鍵盤 WASD 或畫面方向鍵開始移動')}>開始探索 <Compass size={17}/></button><button className="secondary" onClick={()=>setAccount(true)}>建立旅人帳戶</button></div></div><div className="hero-note"><span>01 / 05</span><div></div><small>FIVE ISLANDS<br/>ONE CULTURAL WORLD</small></div></section>
  <section className="world-wrap"><div className="world-heading"><div><div className="eyebrow">THE DIGITAL PARK</div><h2>探索文化群島</h2><p>移動角色，靠近島嶼與引路人，開啟每一段故事。</p></div><div className="control-hint"><span>PC</span> WASD / 方向鍵移動　<span>手機</span> 使用畫面方向鍵</div></div>
   <div className="world-frame"><Canvas shadows camera={{position:[0,8,13],fov:48}} dpr={[1,1.6]} gl={{antialias:true,alpha:false}}><color attach="background" args={['#b9d0c8']}/><fog attach="fog" args={['#b9d0c8',22,48]}/><ambientLight intensity={1.25}/><directionalLight position={[8,12,5]} intensity={2.2} castShadow shadow-mapSize={[1024,1024]}/><Sky sunPosition={[8,5,3]} turbidity={8} rayleigh={1.8}/><Sparkles count={75} scale={[24,5,24]} size={2} speed={0.2} opacity={0.35}/><IslandWorld keys={keys} islands={islands} onSelect={openIsland} onNear={setActive} remotePlayers={remotePlayers} onPosition={sendPosition}/><OrbitControls enablePan={false} enableZoom={false} enableRotate={false}/></Canvas>
    <div className="world-overlay"><span className="live-dot"></span> 3D 探索模式 <span className="overlay-sep">•</span> {user?'旅人已登入':'訪客模式'} <span className="overlay-sep">•</span> {hasSupabase?`線上旅人 ${onlineCount}`:'多人連線待設定'}</div>
    <div className="world-legend"><b>群島索引</b>{islands.map((i,n)=><button key={i.id} onClick={()=>openIsland(i.id)}><i style={{background:i.color}}></i>{String(n+1).padStart(2,'0')} {i.name}</button>)}</div>
    <div className="mobile-pad"><button onPointerDown={()=>setKeys(k=>({...k,w:true}))} onPointerUp={()=>setKeys(k=>({...k,w:false}))} onPointerLeave={()=>setKeys(k=>({...k,w:false}))}><ArrowUp/></button><div><button onPointerDown={()=>setKeys(k=>({...k,a:true}))} onPointerUp={()=>setKeys(k=>({...k,a:false}))} onPointerLeave={()=>setKeys(k=>({...k,a:false}))}><ArrowLeft/></button><button onPointerDown={()=>setKeys(k=>({...k,s:true}))} onPointerUp={()=>setKeys(k=>({...k,s:false}))} onPointerLeave={()=>setKeys(k=>({...k,s:false}))}><ArrowDown/></button><button onPointerDown={()=>setKeys(k=>({...k,d:true}))} onPointerUp={()=>setKeys(k=>({...k,d:false}))} onPointerLeave={()=>setKeys(k=>({...k,d:false}))}><ArrowRight/></button></div></div>
    <div className="world-caption">概念型 3D 園區原型｜非官方建築測繪模型</div>
   </div>
  </section>
  <section className="island-section"><div className="section-title"><div><div className="eyebrow">FIND YOUR OWN STORY</div><h2>五座島嶼，五種相遇</h2></div><p>每座島嶼都藏著一段文化故事，<br/>選擇目的地，展開探索。</p></div><div className="island-grid">{islands.map((i,n)=><button className="island-tile" key={i.id} onClick={()=>openIsland(i.id)}><span className="tile-no">0{n+1}</span><span className="tile-symbol" style={{background:i.color}}>{['墨','瓷','織','文','藏'][n]}</span><b>{i.name}</b><small>{i.subtitle}</small><span className="tile-arrow">↗</span></button>)}</div></section>
  <footer><div className="brand"><span className="brand-mark">拾</span><span><b>故宮南院・拾境</b><small>AN INTERACTIVE CULTURAL EXPERIENCE</small></span></div><p>本網站為文化探索概念原型，非國立故宮博物院官方網站。</p><span>© 2026 拾境 Digital Experience</span></footer>
  {account&&<AccountModal onClose={()=>setAccount(false)} user={user} onLogin={login} onLogout={logout}/>}
  {shop&&<ShopModal cart={cart} setCart={setCart} onClose={()=>setShop(false)}/>}
  {story&&<StoryModal island={story} onClose={()=>setStory(null)}/>}
  {chat&&<div className="chat-card"><button className="close" onClick={()=>setChat(null)}><X/></button><div className="npc-avatar">✦</div><div className="eyebrow">ISLAND GUIDE · NPC</div><b>{chat.npc}</b><p>「{chat.greeting}」</p><button className="secondary wide" onClick={()=>{setStory(chat);setChat(null);}}>閱讀完整島嶼故事</button></div>}
  {active&&!chat&&!shop&&<div className="interaction-tip" onClick={()=>setChat(active)}><MessageCircle size={16}/> 與 {active.npc} 交談</div>}
  {toast&&<div className="toast">{toast}</div>}
 </main>
}
export default App;
