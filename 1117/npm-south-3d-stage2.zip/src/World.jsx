import React, { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { Text } from '@react-three/drei';
import * as THREE from 'three';

const spots = [
 {id:'ink',x:-7,z:-3,c:'#a7c4bb',r:2.0,label:'水墨之島'},
 {id:'ceramic',x:-3,z:3,c:'#78a8b0',r:1.9,label:'瓷器之島'},
 {id:'textile',x:2,z:-3.4,c:'#c7a17b',r:1.9,label:'織夢之島'},
 {id:'civil',x:6,z:2.8,c:'#b6a2c5',r:2.0,label:'文明之島'},
 {id:'shop',x:0,z:6.2,c:'#d4bc7f',r:1.65,label:'拾藏之島'}
];

function Island({spot,onSelect}) {
 return <group position={[spot.x,0,spot.z]} onClick={e=>{e.stopPropagation();onSelect(spot.id);}}>
  <mesh rotation={[-Math.PI/2,0,0]} receiveShadow><circleGeometry args={[spot.r,8]}/><meshStandardMaterial color={spot.c} roughness={0.9}/></mesh>
  <mesh position={[0,0.12,0]}><cylinderGeometry args={[spot.r*0.82,spot.r,0.22,9]}/><meshStandardMaterial color="#e9dfc7"/></mesh>
  <mesh position={[0,0.36,0]}><cylinderGeometry args={[0.3,0.45,0.5,7]}/><meshStandardMaterial color="#6b8173"/></mesh>
  <mesh position={[0,0.85,0]}><coneGeometry args={[0.8,1.2,7]}/><meshStandardMaterial color={spot.c} roughness={0.8}/></mesh>
  <Text position={[0,1.8,0]} fontSize={0.34} color="#17383b" anchorX="center" outlineWidth={0.025} outlineColor="#edf1e8">{spot.label}</Text>
  <mesh position={[0,0.3,spot.r*0.58]}><boxGeometry args={[0.55,0.45,0.1]}/><meshStandardMaterial color="#f1e9d5"/></mesh>
 </group>
}

function AnimeAvatar({position=[0,0.5,0],remote=false,name='拾境旅人',refGroup}) {
 const group=useRef();
 useFrame(()=>{if(refGroup)refGroup.current=group.current;});
 return <group ref={group} position={position} scale={remote?0.86:1}>
  {/* soft shadow */}
  <mesh rotation={[-Math.PI/2,0,0]} position={[0,0.015,0]}><circleGeometry args={[0.42,24]}/><meshBasicMaterial color="#365c56" transparent opacity={0.22}/></mesh>
  {/* legs */}
  <mesh position={[-0.13,0.22,0]} castShadow><capsuleGeometry args={[0.085,0.28,4,8]}/><meshStandardMaterial color="#f2eee3"/></mesh>
  <mesh position={[0.13,0.22,0]} castShadow><capsuleGeometry args={[0.085,0.28,4,8]}/><meshStandardMaterial color="#f2eee3"/></mesh>
  {/* outfit */}
  <mesh position={[0,0.62,0]} castShadow><coneGeometry args={[0.31,0.66,8]}/><meshStandardMaterial color={remote?'#d6a5a0':'#6e9990'} roughness={0.8}/></mesh>
  <mesh position={[0,0.77,0.015]}><sphereGeometry args={[0.22,16,12]}/><meshStandardMaterial color="#eec9ac"/></mesh>
  {/* anime hair cap and side locks */}
  <mesh position={[0,0.94,-0.015]}><sphereGeometry args={[0.245,16,12,0,Math.PI*2,0,Math.PI*0.72]}/><meshStandardMaterial color={remote?'#755d83':'#283e49'}/></mesh>
  <mesh position={[-0.19,0.79,0.03]} rotation={[0,0,0.2]}><capsuleGeometry args={[0.07,0.27,4,8]}/><meshStandardMaterial color={remote?'#755d83':'#283e49'}/></mesh>
  <mesh position={[0.19,0.79,0.03]} rotation={[0,0,-0.2]}><capsuleGeometry args={[0.07,0.27,4,8]}/><meshStandardMaterial color={remote?'#755d83':'#283e49'}/></mesh>
  {/* eyes */}
  <mesh position={[-0.085,0.79,0.205]}><sphereGeometry args={[0.027,8,8]}/><meshBasicMaterial color="#293b42"/></mesh>
  <mesh position={[0.085,0.79,0.205]}><sphereGeometry args={[0.027,8,8]}/><meshBasicMaterial color="#293b42"/></mesh>
  <mesh position={[0,0.72,0.218]}><sphereGeometry args={[0.012,6,6]}/><meshBasicMaterial color="#bd8270"/></mesh>
  <mesh position={[0.3,0.78,0]} rotation={[0,0,-0.35]}><capsuleGeometry args={[0.055,0.24,4,8]}/><meshStandardMaterial color="#eec9ac"/></mesh>
  <mesh position={[-0.3,0.78,0]} rotation={[0,0,0.35]}><capsuleGeometry args={[0.055,0.24,4,8]}/><meshStandardMaterial color="#eec9ac"/></mesh>
  <Text position={[0,1.35,0]} fontSize={0.16} color="#24464a" anchorX="center" outlineWidth={0.018} outlineColor="#f5f2e9">{name}</Text>
 </group>;
}

function Player({keys,onPosition}) {
 const ref=useRef(); const velocity=useRef(new THREE.Vector3()); const lastSent=useRef(0);
 useFrame((state,delta)=>{
  if(!ref.current)return;
  const x=(keys.d||keys.arrowright?1:0)-(keys.a||keys.arrowleft?1:0);
  const z=(keys.s||keys.arrowdown?1:0)-(keys.w||keys.arrowup?1:0);
  const v=new THREE.Vector3(x,0,z);if(v.length()>0)v.normalize();
  velocity.current.lerp(v.multiplyScalar(4.2),Math.min(1,delta*9));
  ref.current.position.x=THREE.MathUtils.clamp(ref.current.position.x+velocity.current.x*delta,-10,10);
  ref.current.position.z=THREE.MathUtils.clamp(ref.current.position.z+velocity.current.z*delta,-8,9);
  if(velocity.current.length()>0.2)ref.current.rotation.y=Math.atan2(velocity.current.x,velocity.current.z);
  if(state.clock.elapsedTime-lastSent.current>0.18){lastSent.current=state.clock.elapsedTime;onPosition?.({x:ref.current.position.x,z:ref.current.position.z});}
 });
 return <AnimeAvatar refGroup={ref}/>;
}

function RemoteAvatar({player}) {
 const target=useRef(new THREE.Vector3(player.position?.x||0,0.5,player.position?.z||0));
 const group=useRef();
 useFrame(()=>{
   target.current.set(player.position?.x||0,0.5,player.position?.z||0);
   if(group.current)group.current.position.lerp(target.current,0.12);
 });
 return <AnimeAvatar refGroup={group} remote name={player.name||'旅人'}/>;
}

export function IslandWorld({keys,islands,onSelect,remotePlayers=[],onPosition}) {
 const water=useRef();
 useFrame(({clock})=>{if(water.current)water.current.position.y=-0.16+Math.sin(clock.elapsedTime*0.7)*0.025;});
 return <group>
  <mesh ref={water} rotation={[-Math.PI/2,0,0]} position={[0,-0.16,0]} receiveShadow><planeGeometry args={[42,34,1,1]}/><meshStandardMaterial color="#83b9b3" roughness={0.22} metalness={0.12}/></mesh>
  <mesh rotation={[-Math.PI/2,0,0]} position={[0,-0.25,0]}><planeGeometry args={[200,200]}/><meshStandardMaterial color="#9db49b"/></mesh>
  {spots.map(s=><Island key={s.id} spot={s} onSelect={onSelect}/>)}
  {/* stylized miniature trees */}
  {Array.from({length:11},(_,i)=><group key={i} position={[-11+(i%6)*4.2,0,-8+Math.floor(i/6)*15]}>
    <mesh position={[0,0.45,0]}><cylinderGeometry args={[0.07,0.1,0.9,6]}/><meshStandardMaterial color="#8b735b"/></mesh>
    <mesh position={[0,1.15,0]}><icosahedronGeometry args={[0.68,0]}/><meshStandardMaterial color={i%2?'#779c7d':'#8eaa87'}/></mesh>
    <mesh position={[0.22,1.35,0.08]}><icosahedronGeometry args={[0.28,0]}/><meshStandardMaterial color="#b6c99c"/></mesh>
  </group>)}
  {/* curved stepping bridges */}
  {[-1,1].map((side,i)=><group key={side} position={[side*4.2,0.02,0]} rotation={[0,side*0.15,0]}>
    <mesh rotation={[-Math.PI/2,0,0]}><boxGeometry args={[0.75,5.5,0.16]}/><meshStandardMaterial color="#e8dec6"/></mesh>
    {Array.from({length:6},(_,n)=><mesh key={n} position={[0,0.12,-2.3+n*0.9]}><boxGeometry args={[0.95,0.08,0.22]}/><meshStandardMaterial color="#bcae91"/></mesh>)}
  </group>)}
  {/* distant pavilion */}
  <group position={[0,0,-10]}>
   <mesh position={[0,1,0]}><boxGeometry args={[3,1.6,2]}/><meshStandardMaterial color="#d8d0b9"/></mesh>
   <mesh position={[0,2,0]}><coneGeometry args={[2.2,0.8,4]}/><meshStandardMaterial color="#526e66"/></mesh>
   <mesh position={[0,2.5,0]}><sphereGeometry args={[0.13,8,8]}/><meshStandardMaterial color="#c5a56e" metalness={0.5}/></mesh>
  </group>
  <Player keys={keys} onPosition={onPosition}/>
  {remotePlayers.map(p=><RemoteAvatar key={p.id} player={p}/>)}
  <Text position={[0,4,-10]} fontSize={0.55} color="#24474a" anchorX="center">拾境 · 文化群島</Text>
 </group>
}
